---
name: cityu-stem-application
description: Draft ITC STEM internship applications for Ryan — find the role in the CityU job sheet, write a short tailored cover email against his verified background, and create it as an Apple Mail draft. Use when Ryan names an employer or role from the ITC STEM Internship Scheme job list, or asks for a cover email, application, or personal statement for a STEM internship. Never send email; only Ryan sends.
---

# CityU ITC STEM Internship Applications

Ryan applies to Hong Kong STEM internships listed in a CityU Government-funded ITC STEM Internship Scheme job sheet. Each application is an email with his CV attached, usually with an optional cover letter in the body.

**Hard rule: never send email.** Create drafts only, in Apple Mail, and tell him it is ready for review. Sending is his action alone. Do not use `send` in AppleScript, do not click send, and do not offer to send.

## Ryan's background

Use only what is verified below. If a claim is not here, do not invent it — check `~/Code` or his GitHub (`gh`, login `<user>`) first, or ask.

### Identity and contact

| Field | Value |
|---|---|
| Full name | Ryan Hendra Wiguna |
| Preferred name | Ryan |
| CityU email (primary) | <email> |
| CityU Exchange address in Mail | <email> |
| iCloud | <email> |
| Other | <email> |
| Personal site email | <email> |
| Website | www.axesys.xyz |
| Phone | +852 7052 0831 (70520831) |
| Address | 22 Cornwall Street, Hong Kong |
| GitHub | github.com/<user> |
| LinkedIn | not on file — ask before referencing one |

### Education

- **BSc Data Science, City University of Hong Kong** — Aug 2025 to present, UG Year 2 as of Oct 2026. cGPA 3.85/4.3.
- **High School Diploma, Natural Sciences, Cahaya Bangsa Classical School** — Aug 2011 to Jun 2025, 3.96 GPA. Student Council Treasurer 2022–2024; founded the Math Club 2024.

### Work eligibility

Hong Kong residency status is not recorded. Ask before filling any eligibility field; do not assume PR, NOL, or visa-needed.

### Languages

Indonesian (native), English (IELTS C1). Chinese proficiency is **not** established — several listings ask for "English and Chinese", so flag this rather than claiming it. Chinese full name is not on file.

### Certifications

- Intro to Data Analytics — RevoU
- Launching into Machine Learning — Google

### Experience

**Full Stack Developer, SnapFeedback Limited** — Jun 2026 to Jul 2026, later extended.
Smart-glasses product. Scoped and built across Arduino/ESP32 firmware, backend, frontend, DevOps and cloud infrastructure. Firmware is Arduino C++ on a Seeed XIAO ESP32-S3 with camera, microphone, OLED and peripheral drivers; the cloud transport holds a TLS-pinned secure WebSocket to a relay and carries JSON control frames plus binary audio from two FreeRTOS tasks under a mutex, with reconnect backoff, ring-buffered audio and BLE+WiFi RAM management. Also wrote the SwiftUI iOS app and the TypeScript/Node Gemini relay. Repo: `~/Code/snapfeedback`.

**Data Science and AI Robotics Engineer, Vinci Analytics** — Mar 2026 to Apr 2026.
Prepared robotics and AI teaching material for primary and secondary schools; built robots and wrote the code for education events.

**Volunteer web developer, HMCC Hong Kong** — ongoing, self-directed contribution.
Two things worth citing:

- **hmcchk-web** (`~/Code/hmcc/hmcchk-web`) — the church's web platform: SailsJS (Node) backend with a React (Chakra UI, Redux Toolkit) front end, Redis-backed sessions, JWT auth, Google OAuth, ag-grid tables, TipTap editor. Ryan's shipped work is SSR for the events page (GH-1487): a Sails controller and helper rendering the page server-side, a Vite SSR entry and config on the React side, and event list helpers. That is real evidence of working across both layers of a production app with a review-and-release branch workflow. Say what he did (server-rendering the events page, plus the API and data handling behind it), not a list of libraries.
- **soapy / Daily SOAP** (`~/Code/hmcc/soapy`) — a Flutter app (Dart, Firebase: Auth, Firestore, Functions, Crashlytics, Messaging) for Bible reading and meditation, released on both the App Store and Google Play, currently at version 2.2.3. He owns release engineering: Fastlane lanes for TestFlight and Play Console, build-number handling, CI on GitHub Actions, and a TypeScript Firebase Functions backend (Bible provider, reading plans, reminder throttling) with unit tests. Good evidence for mobile plus backend plus shipping.

**FLAIM Officer, AIESEC Hong Kong @ CityU Local Committee** — Sept 2025 to Sept 2026.
Analysed operational data and streamlined admin workflows, cutting processing time 20%. Monitored financial data and KPIs for 3+ internal projects at 100% regulatory compliance. Ran information systems for data governance across 5 key metrics.

**Intern, RS. Cahya Kawaluyan (hospital)** — Jun 2024, 4 weeks.
Rotational across IT, marketing and patient care; analysed workflows in laboratory, pharmacy and inpatient services to find bottlenecks.

### Evidence Ryan wants used — and what he does not

Lead with these, roughly in this order: **SnapFeedback**, the **HMCC web work** (hmcchk-web and Daily SOAP), **Vinci Analytics**, and the **portfolio AI systems demo**.

- **Portfolio AI systems demo** — real-time webcam object detection, smart-glasses-style AR overlays, session analytics, backend APIs, AWS cloud/DevOps planning. Video: https://www.youtube.com/watch?v=q23CW41zKaI. Ryan has written the sentence himself as: "I also recently developed a portfolio AI systems demo involving real-time webcam object detection, smart-glasses-style AR overlays, session analytics, backend APIs, and AWS cloud/DevOps planning." Prefer his wording when it fits.
- **anistream / anistream-android** — native iOS (Swift + VLCKit) and Android (Kotlin) apps; shows mobile depth beyond Flutter/React Native.
- **Infrastructure** — Docker and Docker Compose for game servers and services, Fly.io and Render deploys, frp tunnelling, Terraform for the SnapFeedback relay, Cloudflare and Coolify familiarity.

**Do not cite arqos or MTR Flow Analytics in applications.** Ryan ruled both out on 2026-11-04 — they read as personal AI/ML side projects and he would rather the church web contributions, Vinci and SnapFeedback carry the application. This holds even when one of them is the best technical match for a posting. Use SnapFeedback, HMCC, Vinci or the AI demo instead.

### Skills summary

Python (ML, FastAPI), TypeScript/JavaScript, C/C++ (embedded, ESP32), Swift, Kotlin, R, SQL. React/Next.js, SwiftUI, Flutter exposure via coursework. PostgreSQL, Supabase, pgvector, MongoDB. Docker, Terraform, Git throughout. GCP (Cloud Run, Artifact Registry, load balancing), AWS familiarity, Cloudflare. Arduino, PlatformIO/Arduino frameworks, BLE, WiFi, MQTT concepts.

### Honest gaps — do not claim these

- **OTA updates and IoT security hardening** — read about, not shipped. Say so plainly if a role asks.
- **AWS S3/EC2/Lambda** — conceptual, not hands-on. Say "keen to work with" rather than "experienced in".
- **Chinese language** — unverified.
- **Work eligibility status** — unverified.
- **arqos and MTR Flow Analytics** — do not cite them at all in applications, per the evidence section above.

## Find the role

The job sheet is an `.xlsx` in `~/Downloads`, named like `2026.10.29 Job List.xlsx` — take the newest match. Sheet name `Job List`; row 1 is the scheme title, row 2 is headers, data starts row 3.

Columns: `No.`, `Date`, `Company/Organisation Name`, `Company /Organisation Overview`, `Company Website`, `Job Title`, `Job Description`, `Job Requirements`, `Working location`, `Proposed Internship Start Date`, `Proposed Internship Duration`, `No. of Vacancies for this position`, `Honorarium on top of Scheme allowance`, `Application Procedures`, `Email for Submission of Application`, `Application Deadline`, `Remarks-other specific requirements`.

Read it with:

```bash
python3 -I -c "
import openpyxl
wb=openpyxl.load_workbook('~/Downloads/2026.10.29 Job List.xlsx', data_only=True)
ws=wb['Job List']
hdr=[c.value for c in ws[2]]
for row in ws.iter_rows(min_row=3, values_only=True):
    if row[2] and 'COMPANY' in str(row[2]).lower():
        for h,v in zip(hdr,row):
            if v not in (None,''): print(f'--- {h}:\n{v}')
" 2>&1
```

Match on company name and role title, case-insensitively; a company usually has several roles, so confirm which one. Report back the role number, deadline, duration, start date, vacancies, and submission email before drafting. If several companies match loosely, ask which.

Deadlines in the sheet are inconsistent — some `DD/MM/YYYY` text, some ISO datetimes, occasional typos like `12//11/2026`. Read them carefully and state the deadline as you interpret it.

## Shape of the email

Ryan wants very short — four short paragraphs, roughly 130–150 words, and no sign-off block at all. This is the format he settled on for 2038 MR Limited and wants used going forward:

```
Dear <Company> Hiring Team,

I am applying for the <ROLE> role <one clause on what the team does>. I am a second-year BSc Data Science student at City University of Hong Kong, and <one sentence on why this particular problem interests you, drawn from the company overview>.

I was <recent role> at <company>, <what he built, in plain words>, and <earlier role> at <company>, <what he built>. Separately I built a portfolio AI systems demo with real-time webcam object detection, AR overlays and backend APIs, available at https://www.youtube.com/watch?v=q23CW41zKaI

I have not yet worked on <the thing they do> at commercial scale, and that is something I want to go deeper on.

My resume is attached.

Best regards,
Ryan Hendra Wiguna
```

Rules that this format encodes:

1. **Subject** — exactly `[CityU ITC STEM] ROLE - Ryan Hendra Wiguna`, with `ROLE` replaced by the job title from the sheet.
2. **Salutation** — `Dear <Company> Hiring Team,`. Use the company name from the sheet.
3. **Paragraph 1** — role applied for, who he is (BSc Data Science, City University of Hong Kong), and why this company's actual problem interests him. Draw the why from the overview in the sheet, not generic flattery.
4. **Paragraph 2** — the evidence, as one flowing paragraph of past roles joined by "and". The AI demo sentence is a standing third item and can be kept almost verbatim. Pick from SnapFeedback, the HMCC web work (see above), Vinci Analytics and the AI demo — never arqos or MTR Flow Analytics. Plain language: name the technology and what it did, skip mutex/ring-buffer/datasheet-level detail. Detail belongs in an interview.
5. **Paragraph 3** — the honest gap. If they list something he lacks, name it as something he wants to go deeper on. This has landed well; keep it brief and unapologetic. If the role has no such gap, cut the paragraph.
6. **Paragraph 4** — `My resume is attached.` on its own. Note the spelling: **resume**, not CV.
7. **Sign-off** — `Best regards,` then `Ryan Hendra Wiguna`. **Nothing else.** No degree line, no email, no phone, no website. His signature handles contact details, and he cut that block himself.

No availability or start-date sentence by default. Do not add one unless the posting asks, and never invent a date.

Cut ruthlessly. No "I am writing to express my keen interest", no restating the job description, no bullet lists, no three-paragraph build-ups. If a sentence could be deleted without losing a fact, delete it.

**No ellipses.** Ryan has called this out twice. Never use `...` anywhere in the subject or body — not to trail off an intro, not in a placeholder, not in a quote. Same for the em-dash aside; keep sentences declarative.

When the posting says cover letters are optional, still include a body — it is the differentiator. When it names required attachments or details (student ID, department, cover letter as a separate file), list those back to Ryan so he can supply them.

## Personal statements

Some listings use an application form with a free-text Personal Statement field instead of a cover email. Then write **one paragraph**, around 100–120 words, no bullets, no headings: who he is, one proof point, what he would do for them. The same evidence rules apply.

## Create the draft in Apple Mail

Draft on the CityU Exchange account. Never send.

```bash
osascript -e 'tell application "Mail" to get name of every account'
```

`get email addresses of account "Exchange"` fails with `-1728` on this machine even though the account exists. Use the account **name** — it is `Exchange` — and address the mailbox as `mailbox "Drafts" of account "Exchange"`.

Build the message with an AppleScript file under `/tmp`, then run it. Key points learned the hard way:

- `content` is **plain text**. HTML tags render literally in the draft; never pass HTML.
- Set `content` in the `make new outgoing message` properties, not afterwards, then attach.
- Use `linefeed` between paragraphs, not `\n`.
- A trailing `￼` (object replacement character) in the readback means the attachment is present.
- Attaching then resetting `content` can drop the attachment; rebuild the whole draft instead of editing it.
- `mail attachments` cannot be read from an unsaved outgoing message; verify the `￼` instead.
- To replace a draft, close the old one with `close m saving no`, then create fresh.

**Verifying the draft.** Once Mail has autosaved, read it back from the Drafts mailbox rather than from `outgoing messages`:

```applescript
tell application "Mail"
	set d to mailbox "Drafts" of account "Exchange"
	repeat with m in messages of d
		set c to "" & (content of m)
		log (id of m) & " ATTACH: " & (count of mail attachments of m) & " ARQOS: " & (c contains "arqos")
	end repeat
end tell
```

`outgoing message 1` frequently reports `Invalid index` after the message is saved, and `messages` there is an unreliable list — use the mailbox. Coerce content to text with `"" & (content of m)` before measuring or searching it; `length of content of m` throws `-1700`. Check `count of mail attachments of m` and search the body for banned project names before you report back.

**Deleting a stale draft.** `close` does not reliably remove an already-saved message, and a rebuild loop can leave duplicates. Delete by id and then re-list to confirm:

```applescript
tell application "Mail"
	delete (first message of mailbox "Drafts" of account "Exchange" whose id is DRAFT_ID)
end tell
```

Template:

```applescript
tell application "Mail"
	set subj to "[CityU ITC STEM] ROLE - Ryan Hendra Wiguna"
	set body to "Dear X Hiring Team," & linefeed & linefeed & "PARAGRAPH 1" & linefeed & linefeed & "PARAGRAPH 2" & linefeed & linefeed & "PARAGRAPH 3" & linefeed & linefeed & "My resume is attached." & linefeed & linefeed & "Best regards," & linefeed & "Ryan Hendra Wiguna"

	set newMsg to make new outgoing message with properties {subject:subj, content:body, visible:true}
	tell newMsg
		set sender to "<email>"
		make new to recipient at end of to recipients with properties {address:"EMAIL_FROM_SHEET"}
		make new attachment with properties {file name:POSIX file "~/Downloads/Resume.pdf"} at after the last paragraph
	end tell
	return "DRAFT_OK"
end tell
```

The CV lives at `~/Downloads/Resume.pdf`. Check its modification date **and read it**, because a recent mtime does not mean the content is current. As of 2026-11-04 the file (dated 30 Oct 2026) still opens with "A motivated data science freshman", predates the SnapFeedback firmware work, and has Vinci Analytics (Mar–Apr 2026) listed above SnapFeedback (Jun–Jul 2026). Warn Ryan about staleness before he sends rather than silently attaching it, and do not write ordering language in the email ("before that", "most recently") that contradicts the CV's dates — check the two against each other.

After creating, verify the draft by reading back subject, sender and recipient, and confirm the `￼`. Tell him plainly that it is a draft awaiting his review, and flag any CV staleness or unverified claim in the email.

## Before you finish

- Every factual claim about Ryan traces to this file, his repo, or his GitHub — nothing invented.
- The subject line matches `[CityU ITC STEM] ROLE - Ryan Hendra Wiguna` exactly.
- The body cites at least one of SnapFeedback, the HMCC web work, Vinci Analytics or the AI demo, and contains **no** mention of arqos or MTR Flow Analytics.
- The body contains no `...` anywhere.
- The draft exists, is on the Exchange account, addressed to the sheet's email, with the CV attached, and there is exactly **one** draft for this role — duplicates from rebuilds get deleted.
- Nothing was sent.
