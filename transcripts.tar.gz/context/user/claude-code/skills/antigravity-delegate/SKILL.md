---
name: antigravity-delegate
description: Delegate bulk implementation work to Google Antigravity's `agy` CLI while Claude plans, briefs, verifies and integrates. Use for token-heavy or mechanical work — writing tests, scaffolding files, migrations, mechanical refactors, large-file reading, doc generation — when the plan is already clear and the work just needs doing. Claude never hands over the plan or the verification.
---

# Antigravity delegation

Claude is the orchestrator. `agy` is the worker. Claude decides what to build, writes a
self-contained brief, then reviews and integrates the result. Antigravity spends its own
quota doing the typing.

**Never delegate planning, verification, or merge decisions.** If the task is ambiguous, plan
it first — a vague brief comes back as plausible-looking work that has to be redone.

## Preflight

```bash
command -v agy && agy --version     # expect ~1.5.x at ~/.local/bin/agy
```

Auth uses cached credentials from an interactive `agy` session. If a run returns
`authentication required`, tell Ryan to run `agy` once interactively — do not try to log in.

## Core loop

1. **Plan** — decide files, interfaces, and the check that proves done (usually a test command).
2. **Brief** — write the prompt to a file, not inline. It must name the exact files, the exact
   output, and the command that verifies it. Anything unclear to a fresh agent belongs in the brief.
3. **Delegate** — run through the wrapper below.
4. **Verify** — Claude runs the tests itself. Never trust `status: SUCCESS` as evidence.
5. **Integrate** — read the diff, fix the small stuff directly, re-delegate only if substantially wrong.

## Running a delegation

```bash
~/.claude/skills/antigravity-delegate/scripts/agy-delegate.sh \
  --dir /absolute/path/to/worktree \
  --brief /tmp/brief.txt \
  --out /tmp/agy-result.json
```

It exits non-zero if the run was soft-denied, timed out, or errored, and prints a compact
summary plus the response. Use `--raw` to see the full JSON.

### Write access

Headless `agy` cannot prompt for permission, so a `write_file` it cannot approve is **soft-denied**:
exit 0, empty response, and a populated `denied_actions` array. The wrapper turns that into a
failure so it can't be mistaken for success.

Writes are reliable only inside a **trusted workspace** — the paths listed under
`trustedWorkspaces` in `~/.gemini/antigravity-cli/settings.json` (currently `~/Code`
and `~/Code/hmcc/hmcchk-web`, plus any worktree under them). Prefer working there.

From an untrusted directory, or when a write is refused, switch to **read-only delegation**:
have `agy` return file contents and apply them yourself. This costs a few Claude tokens but is
deterministic.

```bash
# schema.json describing what comes back
{"type":"object","properties":{"files":{"type":"array","items":{"type":"object",
 "properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"]}},
 "summary":{"type":"string"}},"required":["files","summary"]}
```

Then: `--brief ... --schema /tmp/schema.json`, parse `.response` as JSON, write the files yourself,
and run the verification command.

## Model routing

**Default: `gemini-pro-orchestrator-g1-pro` ("Orchestrator (Argon)").** Ryan's standing preference —
use it unless he names another model for the task. It is the only model that picks its own route
internally, so it pays off on anything that spans more than one file.

Switch away from it only when:

| Situation | Model |
|---|---|
| He asks for a specific model | whatever he named |
| Pure mechanical work (renames, boilerplate, formatting) where Orchestrator's routing is wasted | `gemini-3.8-flash-low` |
| Deliberately cheap second opinion on Claude's plan or diff | `gemini-3.8-flash-high` |
| He wants a non-Gemini cross-check | `claude-opus-5-5-high` or `gpt-oss-120b-medium` |

Also available: `gemini-4-argon-*`, `gemini-4-hydrogen-*`, `claude-sonnet-5-5-*`. Full list:
`agy models`. Reasoning effort is baked into the model id; `--effort` is a separate knob.

## Brief template

```
Goal: <one sentence, the outcome>
Workspace: <absolute path>
Files to read: <paths>
Files to create/modify: <paths, and what each must contain>
Constraints: <do not touch X; keep the public API; match the existing style>
Verify with: <exact command>
Report: <what to return — e.g. "summary, files changed, test output">
Do not ask questions. If something is ambiguous, choose the simplest option and say so.
```

## Quota discipline

- **One good brief beats five small ones.** Each run re-reads context; batching is cheaper.
- Don't use `agy` for anything Claude can do in one or two tool calls.
- Don't probe (`agy models`, `agents`, smoke tests) inside a task — the list is in this file.
- Long jobs: `--background` the wrapper, keep working, collect later. Bound parallelism to
  ~2-3 worktrees, and give each its own `git worktree` so they can't collide.

## Known quirks

- **HK location warning** in logs (`LOCATION_NOT_ELIGIBLE`, `aicode FetchConfig 403`) is benign —
  it falls back and continues. Don't chase it.
- `--mode auto` is unavailable on Ryan's account and silently degrades to the default mode.
- Background subagents inside `agy` are separate from this delegation; the brief should stay single-threaded.
- `agy acp` (persistent JSON-RPC server) exists and exposes the same models, but is only worth it
  for multi-turn sessions — the wrapper uses print mode.
- Soft denial is exit 0. Always check `denied_actions`, never just the exit code or `status`.
